export type Plan = {
  id: string;
  name: string;
  // TODO: Put additional metadata here
}

