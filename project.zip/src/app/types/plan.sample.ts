import { Plan } from './plan.type';

export const PlanSample1: Plan = {
  id: 'plan1',
  name: 'Plan 1'
}
export const PlanSample2: Plan = {
  id: 'plan2',
  name: 'Plan 2'
}
export const PlanSample3: Plan = {
  id: 'plan3',
  name: 'Plan 3'
}
export const PlanSample4: Plan = {
  id: 'plan4',
  name: 'Plan 4'
}
export const PlanSample5: Plan = {
  id: 'plan5',
  name: 'Plan 5'
}
export const PlanSample_Added: Plan = {
  id: 'plan6',
  name: 'Plan 6'
}
