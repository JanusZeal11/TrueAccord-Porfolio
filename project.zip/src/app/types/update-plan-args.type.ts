export type UpdatePlanArgsType = {
  id: string;
  value: number;
}
