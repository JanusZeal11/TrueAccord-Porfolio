export type LockPlanArgsType = {
  id: string;
  locked?: boolean;
}
